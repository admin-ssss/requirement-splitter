#!/usr/bin/env python3
"""Read-only checks of project tables; business review and software testing remain separate."""
import argparse
import csv
import json
import re
import sys
import unicodedata
from pathlib import Path

SCHEMAS = json.loads((Path(__file__).resolve().parents[1] / 'references/schemas.json').read_text(encoding='utf-8'))
FRONTMATTER = (Path(__file__).resolve().parents[1] / 'SKILL.md').read_text(encoding='utf-8').split('---', 2)[1]
VERSION_MATCH = re.search(r'^  version: "(\d+\.\d+\.\d+)"$', FRONTMATTER, re.M)
SKILL_VERSION = VERSION_MATCH.group(1) if VERSION_MATCH else '未知'


def split_ids(value):
    return [v.strip() for v in value.split(',') if v.strip()]


def load_tables(root, state, errors, prefix=''):
    tables = {}
    for key, relative in state.get('files', {}).items():
        if key not in SCHEMAS:
            continue
        path = (root / relative).resolve()
        if not path.is_relative_to(root.resolve()):
            errors.append({'table': key, 'message': prefix + '文件必须在项目目录内'})
            continue
        try:
            with path.open(encoding='utf-8-sig', newline='') as f:
                reader = csv.DictReader(f)
                expected = [field['name'] for field in SCHEMAS[key]['fields']]
                actual = reader.fieldnames or []
                legacy = bool(state.get('legacy_layout'))
                extra = {'父记录'} if legacy and key == 'modules' else set()
                valid = (len(actual) == len(set(actual)) and
                         (actual == expected or legacy and set(actual) == set(expected) | extra))
                if not valid:
                    errors.append({'table': key, 'message': prefix + '字段缺失、重复、额外字段或顺序不符',
                                   'expected': expected, 'actual': actual})
                rows = []
                for number, row in enumerate(reader, 2):
                    if None in row or any(v is None for v in row.values()):
                        errors.append({'table': key, 'row': number, 'message': prefix + 'CSV 列数不符'})
                        continue
                    rows.append({k: v.strip() for k, v in row.items()})
                tables[key] = rows
        except (OSError, UnicodeError, csv.Error) as error:
            errors.append({'table': key, 'message': prefix + '无法读取表格：' + str(error)})
    return tables


def validate(root, state, phase='prepare', previous_root=None, previous_state=None):
    errors, warnings = [], []
    tables = load_tables(root, state, errors)

    def error(table, ident, message):
        errors.append({'table': table, 'id': ident, 'message': message})

    def index(key):
        field = SCHEMAS[key]['id_field']
        return {row.get(field, ''): row for row in tables.get(key, [])}

    for key in ('modules', 'requirements', 'acceptance'):
        if key not in tables:
            error(key, '', '缺少源头表文件映射或文件')
    for key, rows in tables.items():
        schema, seen = SCHEMAS[key], set()
        for row in rows:
            ident = row.get(schema['id_field'], '') if schema['id_field'] else ''
            if schema['id_field']:
                if ident in seen:
                    error(key, ident, '编号重复')
                seen.add(ident)
            for field in schema['fields']:
                if field['required'] and not row.get(field['name']):
                    error(key, ident, '必填为空：' + field['name'])
            for field, values in schema['enums'].items():
                if row.get(field) and row[field] not in values:
                    error(key, ident, '取值不合法：' + field)

    modules, requirements, acceptance = index('modules'), index('requirements'), index('acceptance')
    development, tests = index('development'), index('tests')
    platforms = set(state.get('platforms', []))
    legacy_ids = set(state.get('legacy_ids', []))
    blocked = state.get('blocked_requirements', {})
    released = set(state.get('released_requirements', []))
    selected = state.get('selected_outputs', [])
    if not isinstance(selected, list) or len(selected) != len(set(selected)) or not set(selected) <= {'development', 'tests'}:
        error('state', '', 'selected_outputs 必须是 development / tests 的不重复列表')
        selected = []
    if phase == 'deliver' and not selected:
        error('state', '', '正式产物交付必须声明选定产出线；仅整理源头请用 prepare')
    if phase == 'deliver' and not released:
        error('state', '', '没有完整已放行需求，不能生成正式任务或用例')
    for key in selected:
        if phase == 'deliver' and key not in tables:
            error(key, '', '选定产出线缺少文件')
    by_requirement = {ident: [] for ident in requirements}
    for ident, row in acceptance.items():
        rid = row.get('所属需求条目编号', '')
        if rid not in requirements:
            error('acceptance', ident, '所属需求编号不存在')
        else:
            by_requirement[rid].append((ident, row))
        if not re.fullmatch(re.escape('AC-' + rid.removeprefix('R-')) + r'-\d{2,}', ident):
            error('acceptance', ident, '验收编号与所属需求不对应')
        types = [s.strip() for s in re.split(r'[,、+/]', row.get('类型', '')) if s.strip()]
        if not types or not set(types) <= {'正常', '异常', '边界', '性能', '集成', '安全'}:
            error('acceptance', ident, '验收标准类型不合法')
    patterns = {'modules': r'M\d+\.\d+[a-z]*', 'requirements': r'R-M\d+\.\d+[a-z]*-\d{2,}',
                'development': r'T-M\d+\.\d+[a-z]*-\d{2,}',
                'tests': r'TC-[A-Z]{2,6}-[A-Z]{2,6}-\d{2,}(?:-[A-Z]+)?', 'changes': r'C-\d{3,}'}
    for key, pattern in patterns.items():
        for ident in index(key):
            if ident not in legacy_ids and not re.fullmatch(pattern, ident):
                error(key, ident, '编号格式不合法；旧编号需有明确历史登记')
    for rid, row in requirements.items():
        if row.get('模块编号') not in modules:
            error('requirements', rid, '模块编号不在模块清单')
        if row.get('所属端') not in platforms:
            error('requirements', rid, '所属端未在本项目登记')
    for key, name, limit in [('requirements', '需求条目名称', 16), ('requirements', '一句话验收', 30),
                             ('development', '任务名称', 16), ('tests', '用例标题', 20)]:
        for row in tables.get(key, []):
            count = sum(not unicodedata.category(c).startswith(('P', 'Z')) and not c.isspace()
                        for c in row.get(name, ''))
            if count > limit:
                error(key, row.get(SCHEMAS[key]['id_field'], ''), name + '超出长度上限')

    checked = set()

    def check_gate(rid, owner_table='', owner_id=''):
        if rid not in requirements:
            error(owner_table or 'state', owner_id or rid, '引用的需求不存在：' + rid)
            return False
        if rid in checked:
            return True
        checked.add(rid)
        if requirements[rid].get('状态') != '有效' or rid in blocked:
            error('requirements', rid, '需求无效、待确认或受缺口影响，不能放行')
        current = [(aid, ac) for aid, ac in by_requirement[rid] if ac.get('状态') != '已废弃']
        if not 1 <= len(current) <= 8:
            error('requirements', rid, '当前必要验收标准数量不在 1–8 条')
        for aid, ac in current:
            if ac.get('状态') != '已确认':
                error('acceptance', aid, '完整需求仍有必要验收标准未确认')
            proof = state.get('confirmed_acceptance', {}).get(aid, {})
            if (proof.get('content') != ac.get('验收标准内容') or proof.get('source') != ac.get('来源')
                    or not proof.get('evidence')):
                error('acceptance', aid, '缺少与当前文本及来源一致的人工确认记录')
        return True

    if phase == 'deliver':
        for rid in released:
            check_gate(rid)
    task_coverage, ac_coverage = set(), set()
    for tid, row in development.items():
        rids = split_ids(row.get('需求条目编号', ''))
        mids = {requirements[r].get('模块编号') for r in rids if r in requirements}
        for rid in rids:
            if rid not in requirements:
                error('development', tid, '引用的需求不存在：' + rid)
            elif phase == 'deliver' and row.get('状态') not in ('已完成', '已取消'):
                check_gate(rid, 'development', tid)
        mid = row.get('模块编号')
        if mid not in modules or row.get('模块名称') != modules.get(mid, {}).get('模块名称'):
            error('development', tid, '模块编号与名称不一致')
        if mids and mids != {mid}:
            error('development', tid, '任务与需求当前模块不一致')
        ends = set(split_ids(row.get('适用端', '')))
        expected_ends = {requirements[r].get('所属端') for r in rids if r in requirements}
        if ends != {'不限端'} and ends != expected_ends:
            error('development', tid, '适用端与需求所属端不一致')
        if row.get('开发类型') == '前端' and len(ends) != 1:
            error('development', tid, '前端任务跨端，需要复核拆分')
        if row.get('状态') == '阻塞' and not row.get('阻塞原因'):
            error('development', tid, '阻塞任务缺阻塞原因')
        if row.get('状态') != '已取消':
            task_coverage.update(rids)
        deps = split_ids(row.get('依赖任务', '')) if row.get('依赖任务') != '无' else []
        for dep in deps:
            if dep not in development or dep == tid:
                error('development', tid, '前置任务不存在或自依赖：' + dep)
            elif row.get('状态') not in ('已完成', '已取消') and development[dep].get('状态') == '已取消':
                error('development', tid, '活动任务仍依赖已取消的前置任务：' + dep)
    visiting, visited = set(), set()

    def visit(tid):
        if tid in visiting:
            error('development', tid, '任务依赖存在循环')
            return
        if tid in visited:
            return
        visiting.add(tid)
        row = development[tid]
        for dep in split_ids(row.get('依赖任务', '')):
            if dep in development:
                visit(dep)
        visiting.remove(tid)
        visited.add(tid)
    for tid in development:
        visit(tid)
    for tcid, row in tests.items():
        rids = set(split_ids(row.get('需求条目编号', '')))
        aids = split_ids(row.get('验收标准编号', ''))
        active = row.get('用例状态') == '有效'
        for rid in rids:
            if rid not in requirements:
                error('tests', tcid, '引用的需求不存在：' + rid)
            elif active and phase == 'deliver':
                check_gate(rid, 'tests', tcid)
        for aid in aids:
            ac = acceptance.get(aid)
            if not ac or ac.get('所属需求条目编号') not in rids:
                error('tests', tcid, '验收引用不存在或归属错误：' + aid)
            elif active and ac.get('状态') != '已确认':
                error('tests', tcid, '有效用例引用待审核或废弃标准：' + aid)
            elif active:
                ac_coverage.add(aid)
        mids = {requirements[r].get('模块编号') for r in rids if r in requirements}
        if len(mids) != 1 or row.get('模块名称') != modules.get(next(iter(mids), ''), {}).get('模块名称'):
            error('tests', tcid, '用例与需求当前模块不一致')
        if any(row.get('适用端') != requirements[r].get('所属端') for r in rids if r in requirements):
            error('tests', tcid, '用例主执行端与需求所属端不一致')
        if tcid not in legacy_ids:
            platform_abbr = state.get('platform_abbreviations', {}).get(row.get('适用端'))
            module_abbr = state.get('module_abbreviations', {}).get(next(iter(mids), ''))
            if not platform_abbr or not module_abbr or not tcid.startswith('TC-' + platform_abbr + '-' + module_abbr + '-'):
                error('tests', tcid, '用例平台或模块缩写未登记或与编号不一致')
        parent_id = row.get('父用例编号')
        if parent_id:
            parent = tests.get(parent_id)
            if (not parent or parent_id == tcid or parent.get('父用例编号')
                    or parent.get('适用端') != row.get('适用端')
                    or parent.get('模块名称') != row.get('模块名称')
                    or not re.fullmatch(re.escape(parent_id) + r'-[A-Z]+', tcid)):
                error('tests', tcid, '父子用例关系、平台或模块不正确')
        step_numbers = re.findall(r'^\s*(\d+)[.、)）]\s*\S', row.get('测试步骤', ''), re.M)
        outcome_numbers = re.findall(r'^\s*(\d+)[.、)）]\s*\S', row.get('预期结果', ''), re.M)
        if (not step_numbers or step_numbers != outcome_numbers
                or step_numbers != [str(i) for i in range(1, len(step_numbers) + 1)]):
            error('tests', tcid, '步骤与预期需要从 1 连续编号且一一对应')

    expected_acs = {aid for rid in released for aid, ac in by_requirement.get(rid, []) if ac.get('状态') != '已废弃'}
    if phase == 'deliver' and 'development' in selected:
        for rid in released - task_coverage:
            error('coverage', rid, '已放行需求没有开发任务')
    if phase == 'deliver' and 'tests' in selected:
        for aid in expected_acs - ac_coverage:
            error('coverage', aid, '已放行验收标准没有有效用例')
    if previous_root is not None and previous_state is not None:
        previous = load_tables(previous_root, previous_state, errors, '快照：')
        for key, old_rows in previous.items():
            if not SCHEMAS[key]['id_field']:
                continue
            now = index(key)
            field = SCHEMAS[key]['id_field']
            for old in old_rows:
                ident = old.get(field, '')
                if ident not in now:
                    error(key, ident, '历史行已删除或编号改变')
                    continue
                new = now[ident]
                if key == 'acceptance' and old.get('状态') in ('已确认', '已废弃') and old.get('验收标准内容') != new.get('验收标准内容'):
                    error(key, ident, '已确认验收标准被同号改写')
                if key == 'development' and old.get('状态') == '已完成' and new.get('状态') != '已完成':
                    error(key, ident, '已完成任务历史状态被回退')
                if key in ('development', 'tests') and old.get('引入文档版本') != new.get('引入文档版本'):
                    error(key, ident, '首次引入文档版本被改写')
    else:
        warnings.append('未提供上一版快照，本次未校验历史行、确认内容和版本稳定性')
    if state.get('legacy_layout'):
        warnings.append('按已有表布局读取，不能据此认定新交付列序符合当前契约')
    if not state.get('skill_version'):
        warnings.append('旧项目未记录技能版本，不能推断为当前版本；本次校验版本单独记录')
    elif state['skill_version'] != SKILL_VERSION:
        warnings.append('项目记录的技能版本与本次校验版本不同，升级兼容性需按版本规则核对')
    return {'ok': not errors, 'phase': phase, 'validator_skill_version': SKILL_VERSION,
            'project_skill_version': state.get('skill_version', '未知'),
            'material_version': state.get('material_version', '未记录'),
            'delivery_version': state.get('delivery_version', '未记录'),
            'errors': errors, 'warnings': warnings,
            'counts': {key: len(rows) for key, rows in tables.items()},
            'coverage': {'requirements_expected': len(released),
                         'requirements_with_tasks': len(released & task_coverage),
                         'acceptance_expected': len(expected_acs),
                         'acceptance_with_cases': len(expected_acs & ac_coverage)},
            'limits': '只验证机械条件；业务语义、人工确认真实性和实际软件测试需另行核对'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', action='version', version='requirement-splitter ' + SKILL_VERSION)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--phase', choices=['prepare', 'deliver'], default='prepare')
    parser.add_argument('--previous-project', type=Path)
    parser.add_argument('--previous-state', type=Path)
    args = parser.parse_args()
    try:
        if bool(args.previous_project) != bool(args.previous_state):
            raise ValueError('上一版项目和状态文件必须同时提供')
        state = json.loads(args.state.read_text(encoding='utf-8'))
        previous = json.loads(args.previous_state.read_text(encoding='utf-8')) if args.previous_state else None
        result = validate(args.project.resolve(), state, args.phase,
                          args.previous_project.resolve() if args.previous_project else None, previous)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        result = {'ok': False, 'errors': [{'message': '无法校验：' + str(exc)}]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
